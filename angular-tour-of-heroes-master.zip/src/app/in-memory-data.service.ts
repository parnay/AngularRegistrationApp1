export class InMemoryDataService {
  createDb() {
    const heroes = [
      { id: 11,bookname:'Runs in Ruins',bookisbn:'0014',requestedby:'Parnay',requestedon:'5/8/2017', author:'Sunil Gavaskar',publishedon:'15/4/2010' },
      { id: 12,bookname:'India at Risk',bookisbn:'0015',requestedby:'Sudhanshu',requestedon:'6/8/2017', author:'Sunil Gavaskar',publishedon:'15/8/2010' },
      { id: 13,bookname:'My country My Life',bookisbn:'0016',requestedby:'Pankaj',requestedon:'7/8/2017', author:'L.K.Advani',publishedon:'21/4/2010' },
      { id: 14,bookname:'Runs in Ruins',bookisbn:'0014',requestedby:'Parnay',requestedon:'5/8/2017', author:'Sunil Gavaskar',publishedon:'15/4/2010' },
      { id: 15,bookname:'India at Risk',bookisbn:'0015',requestedby:'Sudhanshu',requestedon:'6/8/2017', author:'Sunil Gavaskar',publishedon:'15/8/2010' },
      { id: 16,bookname:'My country My Life',bookisbn:'0016',requestedby:'Pankaj',requestedon:'7/8/2017', author:'L.K.Advani',publishedon:'21/4/2010' },
    ];
    return { heroes };
  }
}
