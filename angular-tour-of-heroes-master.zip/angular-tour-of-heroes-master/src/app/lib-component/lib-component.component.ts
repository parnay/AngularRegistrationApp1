import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-lib-component',
  templateUrl: './lib-component.component.html',
  styleUrls: ['./lib-component.component.css']
})
export class LibComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
