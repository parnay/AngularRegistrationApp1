export class Hero {
  id: number;
  bookname: any;
  bookisbn: string;
  requestedby: string;
  requestedon: string;
  author: string;
  publishedon: number;
}
