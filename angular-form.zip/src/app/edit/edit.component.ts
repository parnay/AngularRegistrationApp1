import { Component, OnInit } from '@angular/core';
import { Hero }    from '../hero';
import {ActivatedRoute, Params, Router} from '@angular/router';
import { HttpClient,HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
private data;
private data1;
  constructor(private router: Router,private route: ActivatedRoute,public http: HttpClient) { }
   powers = ['Really Smart', 'Super Flexible',
            'Super Hot', 'Weather Changer','test data'];
  model = new Hero(18,'', this.powers[0], '','');
  submitted = false;
  onSubmit(val) {
    console.log(val); 
    this.http.post("http://localhost/api/update1.php",val).
subscribe(res=>{
          this.data1=res;
          if(this.data1['Status']==1){this.router.navigate(['/regform/',{foo :this.data1['Status']}]);}         
        });
   }
  newHero() {
    this.model = new Hero(42, '', '','','');
  }
getEmployee(id){
    this.http.get('http://localhost/api/selectone.php').subscribe(
      (data:any)=>{
      this.model=data[0];
      console.log(this.model);
    }
  );
  }

  gettestdata(){
    this.http.get('http://localhost:8080/testapp1/').subscribe(
      (data:any)=>{
      console.log(this.data);
    }
  );
  }
// getalluser(){
//   this.http.get('http://localhost/LMSApp/controller/libraryController.php/ListOfUser')
//   .subscribe((data1:any)=>{this.data=data1;});
// }

  id=this.route.snapshot.params;
  ngOnInit() {
    //this.id
    this.gettestdata();
    this.getEmployee(this.id);
    //this.getalluser();
  }

}
