import { Component } from '@angular/core';
//import { Headers, Http, Response } from '@angular/http';
import { Hero }    from './hero';
import {ActivatedRoute, Params, Router} from '@angular/router';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
@Component({
  selector: 'hero-form',
  templateUrl: './hero-form.component.html'
})
export class HeroFormComponent {
  private data;
  private data1;
  private InsertStatus;
  constructor(private router: Router,private route: ActivatedRoute,public http: HttpClient){
  }

  powers = ['Really Smart', 'Super Flexible',
            'Super Hot', 'Weather Changer','test data'];
  model = new Hero(18, '', this.powers[0], '','');

  submitted = false;

  onSubmit() { 
    this.submitted = true;
   }
  newHero() {
    this.model = new Hero(42, '', '','','');
  }

submitform(val){
this.http.post("http://localhost/api/insert1.php",val).
subscribe(res=>{
          //this.InsertStatus=JSON.stringify(res); // make sure you get data here.
          this.data1=res;
          this.data1['Status'];         
        });

}

getalluser(){
  this.http.get('http://localhost/LMSApp/controller/libraryController.php/ListOfUser')
  .subscribe((data:any)=>{this.data=data});
}
deleteEmployee(id){
  console.log(id);
    this.http.post("http://localhost/api/delete.php",{'id':id}).subscribe(res=>{
          console.log(res);
        });
  }
      status=this.route.snapshot.params['foo']; 
ngOnInit() {
  if(this.status){
    this.data1=this.status;
  } 
  this.getalluser();
  }
}