﻿import { Routes, RouterModule } from '@angular/router';

import { HeroFormComponent } from './hero-form.component';
import {LoginComponent  }   from './login/login.component';
import {EditComponent  }   from './edit/edit.component';
import {EmployeeComponent  }   from './employee/employee.component';



const appRoutes: Routes = [
     { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'regform', component: HeroFormComponent},
    // otherwise redirect to home
    // { path: '**', redirectTo: '' },
     { path: 'login',  component: LoginComponent },
     { path: 'employee',  component: EmployeeComponent },
     { path: 'edit/:id',  component: EditComponent },
];

export const routing = RouterModule.forRoot(appRoutes);