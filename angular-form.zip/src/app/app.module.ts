import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';

import { AppComponent }  from './app.component';
import { routing } from './app.routing';
import { HeroFormComponent } from './hero-form.component';
import { LoginComponent } from './login/login.component';
import {HttpClientModule} from '@angular/common/http';
import { EditComponent } from './edit/edit.component';
import { EmployeeComponent } from './employee/employee.component';
@NgModule({
  imports: [BrowserModule,FormsModule,routing,HttpClientModule],
  declarations: [AppComponent,HeroFormComponent, LoginComponent, EditComponent, EmployeeComponent],bootstrap: [ AppComponent ],

})
export class AppModule { }